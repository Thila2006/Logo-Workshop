import React from "react";
import ReactDOM from "react-dom/client";
import LogoStudio from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <LogoStudio />
  </React.StrictMode>
);
